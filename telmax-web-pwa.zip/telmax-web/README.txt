TELMAX – instalovatelná webová aplikace (PWA)

1) Nahraj celou složku na jakýkoli HTTPS hosting, např. Netlify Drop (app.netlify.com/drop) nebo GitHub Pages.
2) Otevři adresu v Chrome na telefonu, počkej na první načtení.
3) Menu ⋮ > Přidat na plochu / Instalovat aplikaci.
4) Spouští se na celou obrazovku na šířku a po prvním načtení funguje i offline.
